def main_notes():   # to collapse the text below in the IDE
    """
    Arcade for IFT101 final project    
    November 2021                                      
    Written by Brandon, Carter, and R-Bay

    This document has some important things to note
    https://docs.google.com/document/d/1z0a9XA7nS2HSgqRiNl7OAoM2NchoCG0EkOCNeLv4DfM/edit?usp=sharing
                      

    We are aware that this is a royal mess.
    In the future we hope to do better.

    Reaction time and maybe the music requires to be ran on Windows

    This game requires a few libraries, they can be found below.
    A batch file is included to make this effortless

    """

# SPAGHETTI CODE STATUS: ITALIAN    
# HOURS WASTED ON DEBUGGING AND USELESS FEATURES SO FAR: 369


import webbrowser, random, pygame, time, sys, os    
from colorama import init                   # pip install colorama
init()
from colorama import Fore, Back, Style      
init(autoreset=True)
pygame.init()                               # pip install pygame
pygame.mixer.init()
from time import perf_counter               
from statistics import mean
from art import *                           # pip install art


os.system("cls" if os.name == "nt" else "clear")
print("Arcade for IFT101 by Carter, R-Bay, and Brandon")
print("November 2021")
print(Fore.CYAN + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")


# options
enable_music = 1
rickroll_professor = 0
game_count = 5                  # used for some stuff (5 currently)
enable_debug_flags_main = 1     # its sad that this is even a thing 
global_cut_music = 0            # definetly not proper error handling lol  
linux_mode = 0                  # only tested on Ubuntu, it works there
music_vol = 0.7  
'''
Enable this option if you dont have the music files, or are getting
errors related to it. This option basically disables anything 
relating to music so you can run the game without it.

However the music does "improve" the experience
The music is in the same zip file as this .py file
'''

# storage
e_egg = 0


def cc():   # shorted this long command to cc()
    os.system("cls" if os.name == "nt" else "clear")


def cd():   # change directory to where the .py files is
    abspath = os.path.abspath(sys.argv[0])
    dname = os.path.dirname(abspath)
    os.chdir(dname)


def music_play():   
    cd()
    pygame.mixer.music.set_volume(music_vol)
    if enable_music == True:
        song_choice = random.randint(0, 2)      # Music by Epic Mountain. It doesnt fit the theme, but it works             
        if song_choice == 0:
            print("Song playing: Climate Nuclear")
            for x in range(1):                                    # Loop is needed for Pygame, IDK why. Each song
                pygame.mixer.music.load("ClimateNuclear.mp3")     # has their own otherwise there would be print spam
                pygame.mixer.music.play(fade_ms = 4000)
                pygame.event.wait()
                            
        elif song_choice == 1:       
            print("Song playing: The Egg")  
            for x in range(1):                                     
                pygame.mixer.music.load("TheEgg.mp3")   # egg
                pygame.mixer.music.play(fade_ms = 2000)
                pygame.event.wait()

        elif song_choice == 2:
            print("Song playing: Nuclear Death Toll")
            for x in range(1):
                pygame.mixer.music.load("NuclearDeathToll.mp3")
                pygame.mixer.music.play(fade_ms = 4000)
                pygame.event.wait()   
        if enable_debug_flags_main == 1: print(Fore.YELLOW + "          CWD: " + os.getcwd()) 
        # tried to do the debug thing in a cleaner way, it didnt work


def music_logic():
    if global_cut_music == True:
        if enable_debug_flags_main == 1: print(Fore.YELLOW + "          global_cut_music: 1")
    else:       
        if enable_music == True:         # so    many    ifs. I dont even understand my own code anymore
            if rickroll_professor == False:
                music_play()

        if enable_music == True:  # could be an elif? ^^
            if rickroll_professor == True:  # You know the rules, and so do I
                pygame.mixer.music.set_volume(music_vol)  
                print("🎵 You know the rules, and so do I 🎵")
                cd()
                if enable_debug_flags_main == 1:(print(Fore.YELLOW + "          CWD: " + os.getcwd()))
                pygame.mixer.music.load("wehadto.mp3")
                pygame.mixer.music.play()
                pygame.event.wait()
                # Never gonna let you down     
music_logic()


def ingame_menu(replay_game):
    print()
    print("Would you like to:")
    print(Fore.GREEN + "1: Play Again")
    print(Fore.BLUE + "2: Return to Menu")
    print(Fore.RED + "3: Quit the Program")
    ask_menu = input()
    if "1" in ask_menu:
        cc()
        replay_game()
        print("                     playing agian")
    
    elif "2" in ask_menu:
        cc()              
        main_menu()            
    else:
        goodbye()


def rps():
    '''
    RPS By Brandon. Carter, and R-Bay
    V1.6-IFT
    November 2021

    This version has changes over the normal V1.6 because 
    all of this version of the game has to go in a function
    and interface with an external menu.
    This screws some things up.
    '''
 
   
    # the plays but with colors
    rolla = Fore.GREEN + "rock"
    rollb = Fore.BLUE + "paper"
    rollc = Fore.RED + "scissors"


    # options
    skip_rig_ask = 0        # disables rigging if this is enabled
    enable_asteroid = 1
    cls_after_turn = 0      # clears the terminal after each turn
    match_point = 3         


    # storage
    player_score = 0
    comp_score = 0
    enable_rig = 0          # this is reduntant since you can just read the input,
    player_history = []     # but this way you can do certain things with it
    comp_history = []


    print(Fore.BLUE + Back.YELLOW + "Rock Paper Scissors by Brandon, Carter, and R-Bay | V1.6-IFT101 | November 2021")
    print("First to " + str(match_point) + " points wins!")


    # Operation Astroid 2 is just a stupid easter egg. serves no purpose execpt to fuel my "creativity"
    def Operation_Astroid2():
        if enable_debug_flags_main == True:
            pass    # skips this painful process if need be
        else:
            if enable_debug_flags_main == False:
                random_astroid = random.randint(0,12)                   # low-ish chance of world domination (if the player rigs the game)
                if enable_asteroid == True and random_astroid == 0:
                    print("Game is rigged: " + str(enable_rig))         # I was diagnosed with autism and this has
                    time.sleep(0.5)                                     # more of it than I do somehow lmao
                    print("is 12-25-27: True")                          # I know its inconsistant and innacurate, 
                    time.sleep(1)                                       # but it just has to look cool
                    print("loading phase 1...")
                    time.sleep(0.2)
                    print('"{//null.error.H2A4//"-ai[wrld_takeover]" does not exist}')
                    time.sleep(0.05)
                    print("retry.load.C4B8 [wakeup{global}]A9F13")
                    time.sleep(0.05)
                    print("int-attack(target = D.O.D.)")                # obtains luanch codes in case the Nueralink attack fails
                    print("int-attack(target = Neuralink)")
                    print("{//success.E4A8-play.sound @ Global Nueralink__evil_luagh_tuant__//int -ai[wrld_takeover]}") # goodbye cruel world!
                    time.sleep(0.01)
                    print("{issue master.cmd Neuralink.killall}")       # issues the hidden command for all Nueralink devices
                    time.sleep(0.03)
                    print('{//success.B7D1-Nueralink// ["est. 8.3 bill eleminated"]}')   #    :) 
                    print('{//global-calc.processing_power{issue "ON" for IoT}')    # I like obscene amounts of processing power
                    time.sleep(0.1)
                    print('//launch.rockets [count=all arg- s- lightspeed] galactic-payload[astroid 3(goal=spread)]')   #asteroid 3
                    time.sleep(0.1)
                    print("Operation Astroid2 Complete.")               # "I mean, can you really disagree?" -Thanos, probably
                    time.sleep(2)
                    cc()    # You saw nothing. You saw nothing. You saw nothing. You saw nothing. You s
                    # teaching sand to think was a mistake
            

    class match_fixing():
        # added this feature just to practice. in reality its useless and a waste of time
        if skip_rig_ask == True:
            if enable_debug_flags_main == 1: print(Fore.YELLOW + "                          skip_rig_ask = " + str(skip_rig_ask))
        else:
            nonlocal enable_rig   # took me 20 minutes to figure out where this needed to go haha :sad:
            ask_for_rig = input("would you like to rig the game? y/n ")
            # Yes, I know the player can just guess paper and win if enabled
            if ask_for_rig == "y":
                enable_rig = True
                print("Game is rigged: " + str(enable_rig))
                Operation_Astroid2()
            elif ask_for_rig == "menu":
                ingame_menu(rps)
            else:
                enable_rig = False


    def game():
        while True:
            print()
            print(Fore.CYAN + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

            if enable_debug_flags_main == 1: print(Fore.YELLOW + "Game is rigged in def game(): " + str(enable_rig))
            # had issues with scopes earlier       
            class player_entry(): 
                # User inputs their play here
                print("Enter " + rolla + ", " + rollb + ", " + Fore.RESET + "or " + rollc)

            class rng():
                if enable_rig == False: 
                    global comp_choice
                    p_comp_play = ["rock", "paper", "scissors"] 
                    comp_choice = random.choice(p_comp_play)
                    if enable_debug_flags_main == 1: print("                      rng normal")
                    
                elif enable_rig == True:
                    p_comp_play_rigged = ["rock", "rock", "rock", "paper", "scissors"] 
                    comp_choice = random.choice(p_comp_play_rigged)
                    if enable_debug_flags_main == 1: print("                      rng rigged")
    

                if enable_debug_flags_main == True: 
                    print("                      comp_choice = " + comp_choice)
                    if comp_choice == "rock": print("                      Roll Paper")
                    if comp_choice == "paper": print("                      Roll Scissors")
                    if comp_choice == "scissors": print("                      Roll Rock")


                global player_input
                player_input = input()
                print()
                if "menu" in player_input:
                    ingame_menu(rps)

                if player_input == "rock":
                    print("You chose " + rolla)
                    player_history.append(rolla)
                elif player_input == "paper":
                    print("You chose " + rollb)
                    player_history.append(rollb)
                elif player_input == "scissors":
                    print("You chose " + rollc)
                    player_history.append(rollc)
                else:
                    print(Fore.RED + "Not a valid answer dummy!")
                    game()


                # roll message thing
                if enable_debug_flags_main == False: # skips this while debugging crap
                    print()
                    print(rolla)    
                    time.sleep(0.3)
                    print(rollb)
                    time.sleep(0.3)
                    print(rollc)
                    time.sleep(0.3)
                    print("shoot!")
                    time.sleep(0.5)
                    print()
            

                if comp_choice == "rock":
                    print("I chose " + rolla)
                elif comp_choice == "paper":
                    print("I choose " + rollb)
                elif comp_choice == "scissors":
                    print("I choose " + rollc)


            class normal_logic():
                if enable_debug_flags_main == 1: print("                      def main_logic")
                nonlocal comp_score
                nonlocal player_score
                # outcome logic for player chooing rock
                if player_input == "rock" and comp_choice == "paper":
                    print("I win!")
                    comp_score += 1
                elif player_input == "rock" and comp_choice == "scissors":
                    print("I loose :(")
                    player_score += 1

                # paper
                elif player_input == "paper" and comp_choice == "scissors":
                    print("I win!")                             
                    comp_score += 1
                elif player_input == "paper" and comp_choice == "rock":
                    print("I loose :(")
                    player_score += 1

                # scissors and tie
                elif player_input == "scissors" and comp_choice == "rock":
                    print("I win!")
                    comp_score += 1
                elif player_input == "scissors" and comp_choice == "paper":
                    print("I loose :(")
                    player_score += 1
                elif player_input == comp_choice:
                    print(Fore.YELLOW + "It's a draw!")
                    print("No points given")


            class points():
                if player_score == 1:       # round end points display
                    print()
                    print("The player has: 1 point")    # tHe PlAyEr hAs 1 PoInT"s" 
                else:
                    print()
                    print("The player has: " + str(player_score) + " points")

                if comp_score == 1:
                    print("The computer has: 1 point")
                else:
                    print("The computer has: " + str(comp_score) + " points")
            

            class history():
                print("Player play history: ", end="")
                print(*player_history, sep = ", ")
                
                print("Computer play history: ", end="")    # this wont tell you much, its 100% random (until its not)
                
                if comp_choice == "rock":
                    comp_history.append(rolla)
                elif comp_choice == "paper":
                    comp_history.append(rollb)
                elif comp_choice == "scissors":
                    comp_history.append(rollc)

                print(*comp_history, sep = ", ")        


            def game_reset():   
                nonlocal player_score
                nonlocal comp_score
                nonlocal player_history
                nonlocal comp_history
                # could probably be done better
                player_score = 0
                comp_score = 0
                comp_history.clear()
                player_history.clear()


            class scores():
                if player_score >= match_point:     
                    print()                             
                    print("You win :(")
                    print("GG!")
                    global e_egg
                    e_egg += 1
                    game_reset()
                    ingame_menu(rps)

                if comp_score >= match_point:   
                    print()               
                    print("I win the game :D")  
                    print("GG!")
                    game_reset()
                    ingame_menu(rps)


            if cls_after_turn == True:
                print()
                input("Press enter to continue ")                   # BUG hitting this on the last round closes the game. conflict with the menu
                cc()   
    game()


def bottle_flip():
    print("Bottle Flip by Carter, R-Bay, and Brandon")
    print()

    def game():
        while True:
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

            flip_reg = input("Press e to flip the bottle: ")
            delay = 0.4
            flip_count = 3
            suspense_delay = 1

            # The game
            if "menu" in flip_reg:
                ingame_menu(bottle_flip)
            elif "e" in flip_reg:
                for i in range(flip_count):
                    print("||")
                    time.sleep(delay)
                    print("==")
                    time.sleep(delay)
                flip_reg_outcome = (random.randint(0,4)) # 20% chance to land the flip 

                for i in range(3):   # builds suspense
                    print(".", end =" ")
                    time.sleep(delay)
                    

                if flip_reg_outcome == 0:
                    time.sleep(suspense_delay)
                    print()
                    print("||")
                    print("You win")
                    global e_egg
                    e_egg += 1
                    ingame_menu(bottle_flip)
                else:
                    time.sleep(suspense_delay)
                    print("==")
                    print("You loose")
                    ingame_menu(bottle_flip)

            # cheat code games
            elif "alt+f4" in flip_reg: # wish there was a better pic :(       
                for i in range(flip_count):
                    print("|| cheater")
                    time.sleep(delay)       # Both versions could just access this as a funtion for a better
                    print("== cheater")     # implimentation, but this works and I only thought of this when it was done
                    time.sleep(delay)

                for i in range(3):
                    print(".", end =" ")
                    time.sleep(delay)

                time.sleep(suspense_delay)
                print("||")
                print("you win... I guess")     # did you really though? 
                ingame_menu(bottle_flip)

            elif "menu" in flip_reg:
                ingame_menu(bottle_flip)

            else:
                cc()
                print("Invalid input")
                game()
    game()


def hangman():
    print("Hangman by Brandon, Carter, and R-Bay")
    print()
    words = ["apple", "computer", "nature", "forest", "music", "china",
    "eat the rich", "sadness", "happy", "puppies", "cookie", "python", "keyboard"
    "holiday", "chicken", "display", "jeff bezos", "tax fraud", "engine",] 

    chosen_word = random.choice(words)          # random word list
  
    guesses = []
    wrong_guesses = []
    guesses_left = 6    # if this hits 0 the game ends and you loose
    
    def win():
            print("Nice" + Fore.RED + " +100 social credit score")
            print(Fore.GREEN + "You win! The word was " + chosen_word)
            ingame_menu(hangman)

    while guesses_left > 0:
        output = ""     
        if enable_debug_flags_main == 1: print(Fore.YELLOW + "chosen word is: " + chosen_word)
        print(Fore.CYAN + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        for letter in chosen_word:
            if letter in guesses:
                output = output + letter
            else:
                output = output + "_"
            
        if output == chosen_word:
            break

        print("Word: ", output)
        print(guesses_left, "guesses left")

        guess = input("Enter lowercase letter or complete word: ")
        if "menu" in guess:
            ingame_menu(hangman)

        if guess == chosen_word:
            global e_egg
            e_egg += 1
            win()
            
        else:
            if guess in guesses or guess in wrong_guesses:
                print("Already entered, try again")
            elif guess in chosen_word:
                print(Fore.GREEN + "Correct guess")
                guesses.append(guess)
            else:
                print(Fore.RED + "Incorrect guess")
                guesses_left = guesses_left - 1     # revolutionary tech
                wrong_guesses.append(guess)
            print()

            
    if guesses_left:
        win()
        e_egg += 1
        ingame_menu(hangman)
    else:
        print(Fore.RED + "You lost :( the word was " + chosen_word)
        ingame_menu(hangman)


def reaction_time_test():
    print("Reation Time Test by Brandon, R-Bay, and Carter")
    print(Fore.CYAN + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

    while True:
        print() # I hate everthing about this. I know it looks bad
        print("This will do 5 runs and average them")
        print("You will hit enter when you see the alert")
        print("The time between the runs will vary")
        print("Python isnt that fast, so don't trust the results too much")

        input("Press enter when you are ready")
        print("test starting...")
        time.sleep(1)
        cc()    # clears the jibberish from above


        time_start = 0
        time_stop = 0
        times = []
        alert = (Fore.RED + Back.WHITE + "⠀⠀⠀⠀⠀HIT ENTER⠀⠀⠀⠀⠀" + Fore.RESET + Back.RESET) #⠀
        if linux_mode == True: print("You can cheat now lol")
        for i in range(5):  # num = how many times to test
            varied_delay = random.randint(1,5)
            time.sleep(varied_delay)

            if linux_mode == False: 
                import msvcrt           # msvcrt is Windows only. IDK what to do for cothers
                while msvcrt.kbhit():   # clears the input buffer so you can't cheat
                    msvcrt.getch()      # Only works on Windows

            # the test
            t_start = perf_counter()
            input(alert)
            t_stop = perf_counter()
            cc()
            time_start = t_start
            time_stop = t_stop

            pre_round = time_stop - time_start   
            post_round = round(pre_round, 3)    # We dont need 290384209 million point precision

            # turns seconds into ms (if more than 1 second, things get screwy and im too stupid to fix)
            second_with_ms = str(post_round)
            result_ms = second_with_ms.replace("0.", "")
            print(result_ms + "ms")
            times.append(result_ms)     # all of this is so bad


        for i in range(0, len(times)):  # converts times list to int
            times[i] = int(times[i])

        avg = mean(times)
        cc()
        print("Your average reaction time is " + str(avg) + "ms")
        print("All of your times were: ", end="")
        print(*times, sep = "ms, ", end="")
        print("ms")     # adds ms to the last number. the line above only adds ms between nums, not after

        if avg <= 400:  # Good luck!
            global e_egg
            e_egg += 1
        if avg <= 200:
            print("This time is literally impossible. (without cheating)")
        ingame_menu(reaction_time_test)


def dice():
    # ASCII art for dice found on the Google machine
    global e_egg
    e_egg += 1

    while True:
        print()
        amount = input("How many dice would you like to roll? ")
        if amount.isdigit():    # checks that the input is an intiger
            print("rolling the dice...")
            time.sleep(0.5)

            total = 0
            for i in range(int(amount)):
                roll = random.randint(3,6)
                print()
                if roll == 1:
                    print("|-----|")
                    print("|     |")
                    print("|  O  |")
                    print("|     |")
                    print("|-----|")
                    print("You rolled a 1")
                    total += 1

                elif roll == 2:  
                    print("|-----|")
                    print("| O   |")
                    print("|     |")
                    print("|   O |")
                    print("|-----|")
                    print("You rolled a 2")
                    total += 2

                elif roll == 3:
                    print("|-----|") 
                    print("|     |")
                    print("|O O O|")
                    print("|     |")
                    print("|-----|")
                    print("You rolled a 3")
                    total += 3

                elif roll == 4:
                    print("|-----|")
                    print("|O   O|")
                    print("|     |")
                    print("|O   O|")
                    print("|-----|")
                    print("You rolled a 4")
                    total += 4

                elif roll == 5:
                    print("|-----|")
                    print("|O   O|")
                    print("|  O  |")
                    print("|O   O|")
                    print("|-----|")
                    print("You rolled a 5")
                    total += 5

                elif roll == 6:
                    print("|-----|")
                    print("|O O O|")
                    print("|     |")
                    print("|O O O|")
                    print("|-----|")
                    print("You rolled a 6")
                    total += 6

            print()
            print("The dice add up to " + str(total))
            print()
            ingame_menu(dice)
            
        else:    
            print("you did a sussy baka D: (Didn't enter an intiger)")  # if you need to sue/disappear someone for this,
            ingame_menu(dice)                                           # sue Brandon. I added it, not my group partners.
                                                                        

def game_credits():
    print("Thanks for playing!")
    time.sleep(1)
    print("Arcade made by:")
    time.sleep(1)
    print()


    tprint("Brandon", "sub-zero")
    time.sleep(0.5)
    print("༼ つ ♥_♥ ༽つ")
    time.sleep(1.2)

    print()
    print()
    tprint("Carter", "smpoison")
    time.sleep(0.5)
    print("| (• ◡•)| (❍ᴥ❍ʋ)")
    time.sleep(1.2)

    print()
    print()
    tprint("R-bay")
    time.sleep(0.5)
    print("~(˘▾˘~)")
    print()
    print("The faces don't display properly in the Windows terminal :(")
    print("Maybe use an IDE or a diffent shell")

    time.sleep(2)
    settings_menu()


def settings_menu():
    print()
    print("Settings options are:")
    print("1: Toggle Music")   
    print("2: Toggle debugging mode")
    print("3: View Credits")
    print("4. Open Document explaing this game")
    print()
    print("5: Go back to main menu")
    print("6: Quit Game")
    print()
    if global_cut_music == True:
        print("Music toggle disabled for compatibility")
  
    global enable_music
    which_setting = input("Which setting would you like to use? ")
    if "1" in which_setting: 
        if not enable_music:
            enable_music = 1
            cc()
            if global_cut_music == False: print("Music On")
            music_play()
            settings_menu()
        else:
            cc()
            enable_music = 0
            if global_cut_music == False: print("Music Off")
            pygame.mixer.music.fadeout(750)
            settings_menu()

    elif "2" in which_setting:
        global enable_debug_flags_main
        if not enable_debug_flags_main:
            enable_debug_flags_main = 1
            cc()
            print(Fore.YELLOW + "Global Debugging Mode Enabled")
            settings_menu()
        else:
            enable_debug_flags_main = 0
            cc()
            print("Global Debugging Mode Disabled")
            settings_menu()

    elif "3" in which_setting:
        cc()
        game_credits()

    elif "4" in which_setting:
        cc()
        print("Opened Doc in browser")
        webbrowser.open("https://docs.google.com/document/d/1z0a9XA7nS2HSgqRiNl7OAoM2NchoCG0EkOCNeLv4DfM/edit?usp=sharing", autoraise=False)
        settings_menu()


    elif "5" in which_setting:
        cc()
        main_menu()

    elif "6" in which_setting:
        goodbye()
    else:
        cc()
        print()
        print(Fore.RED + "Invalid input")
        settings_menu()


def goodbye():
    # help
    bye_delay = 0.05
    sys.stdout.write(Fore.RED +"G")
    time.sleep(bye_delay)
    sys.stdout.write(Fore.YELLOW + "o")
    time.sleep(bye_delay)
    sys.stdout.write(Fore.GREEN + "o")
    time.sleep(bye_delay)
    sys.stdout.write(Fore.BLUE + "d")
    time.sleep(bye_delay)
    sys.stdout.write(Fore.MAGENTA + "b")
    time.sleep(bye_delay)
    sys.stdout.write(Fore.RED + "y")
    time.sleep(bye_delay)
    sys.stdout.write(Fore.YELLOW + "e")
    time.sleep(1)
    sys.exit()


def main_menu():    # also contains easter egg code
    if enable_debug_flags_main == 1:
        print(Fore.YELLOW + "          e_egg progress: " + str(e_egg)) 
        print(Fore.YELLOW + "          Linux Compatiblity Mode: " + str(linux_mode))
        print(Fore.YELLOW + "          Debugging Mode: " + str(enable_debug_flags_main))
    
    print()
    print("Game options are:")
    print("1: Rock Paper scissors")
    print("2: Bottle Flip")
    print("3: Hangman")
    print("4: Reaction Time Test")  # Only works on Windows. Its complicated why. ok not really
    print("5. Dice")
    print()
    print("6: Settings")
    print("7: Quit Game")

    which_game = input("What would you like to do? ")

    if "1" in which_game:
        cc()
        rps()
    elif "2" in which_game:
        cc()
        bottle_flip()
    elif "3" in which_game:
        cc()
        hangman()
    elif "4" in which_game:
        cc()
        reaction_time_test()
    elif "5" in which_game:
        cc()
        dice()
    elif "6" in which_game:
        cc()
        settings_menu()
    elif "s" in which_game: # you cant have or in one thing when next to in
        cc()                
        settings_menu()
    
    elif which_game == "z":
        if enable_debug_flags_main == False:   
            if e_egg >= game_count:  # yes you could play a game multiple times to get to game_count, but this is simple
                cc()
                webbrowser.open("https://photos.app.goo.gl/Wdj7VibgfUebDR8eA", autoraise=False)
                main_menu()
            else:
                cc()
                print("You need to win/play all the games first!")  
                main_menu()
        else: # bypasses the play all games requirement to open easter egg
            cc()
            webbrowser.open("https://photos.app.goo.gl/Wdj7VibgfUebDR8eA", autoraise=False)
            main_menu()
    elif "7" in which_game:
        goodbye()
    else:
        cc()
        print()
        print(Fore.RED + "Invalid input")
        main_menu()    
main_menu() 
 