This is a simple arcade game for my IFT101 final project. Yes, I know the code is messy and has formatting errors, but it works. This is also my first time using GitHub so this might be completely bunged up idk.

I wanted to add a beta/testing branch but I'm too scared because I know nothing haha. (I ended up doing this and nearly bunged everything up)
This is why you might see that the .py file has been updated, but not the release.
git is scary (sad cheems image goes here)

Read more here:
https://docs.google.com/document/d/1z0a9XA7nS2HSgqRiNl7OAoM2NchoCG0EkOCNeLv4DfM/edit?usp=sharing
