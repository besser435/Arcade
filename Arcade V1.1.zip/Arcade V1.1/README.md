This is a simple arcade game for my IFT101 final project. Yes, I know the code is messy and has formatting errors, but it works. This is also my first time using GitHub so this might be completely bunged up idk.

 finish this readme lol
